package com.example.bajaj.model;

public class UserInfo {
    private String name;
    private String regNo;
    private String email;

    public UserInfo() {}

    public UserInfo(String name, String regNo, String email) {
        this.name = name;
        this.regNo = regNo;
        this.email = email;
    }
}