package com.example.bajaj.model;

import java.util.List;

public class ResultQ1 {
    private String regNo;
    private List<List<Integer>> outcome;

    public ResultQ1(String regNo, List<List<Integer>> outcome) {
        this.regNo = regNo;
        this.outcome = outcome;
    }
}