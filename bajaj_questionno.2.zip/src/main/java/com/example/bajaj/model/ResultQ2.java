package com.example.bajaj.model;

import java.util.List;

public class ResultQ2 {
    private String regNo;
    private List<Integer> outcome;

    public ResultQ2(String regNo, List<Integer> outcome) {
        this.regNo = regNo;
        this.outcome = outcome;
    }
}